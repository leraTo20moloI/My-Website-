--Question 1
 CREATE DATABASE students;
 USE students;
 CREATE TABLE student(id int primary key, fullname varchar(100), age int );

--Question2
INSERT INTO student (id, fullname, age)
 VALUES 
        (1, 'Lerato Moloi', 20),
        (2, 'Mannly Martins', 30),
        (3, 'Agenes Tales', 45)

        --Question 3
 UPDATE student SET age = 20
 WHERE id = 2
